# Translating Akkadian to English with Neural Machine Translation
This Repository contains the Supplementary Information S1-S16.
