### Dataset classes

- `lines_dataset.py`: used for line segmentation training
- `cunei_dataset.py` : used for sign classification training
- `cunei_dataset_ssd.py` : used for sign detector training
- `cunei_dataset_segments.py` : used for evaluation on full tablet image (image + bbox annotations)
- `segments_dataset.py` : used for evaluation on full tablet image (image only)
