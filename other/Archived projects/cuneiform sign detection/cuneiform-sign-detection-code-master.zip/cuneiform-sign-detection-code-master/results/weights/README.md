### Network weights folder
Place pytorch *.pth model files here:

- lineNet_basic_vXXX.pth - line segmentation model
- cuneiNet_basic_vXXX.pth - backbone classifier model 
- fpn_net_vXXX.pth  - detector model

