# tessdata_contrib

User contributed (non Google) data repository for Tesseract 4 (Akkadian, Ancient Greek languages, ...)
