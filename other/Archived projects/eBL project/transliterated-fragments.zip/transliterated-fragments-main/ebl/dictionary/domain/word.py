from typing import NewType

WordId = NewType("WordId", str)
