class NotFoundError(Exception):
    pass


class DuplicateError(Exception):
    pass


class DataError(Exception):
    pass


class Defect(Exception):
    pass
