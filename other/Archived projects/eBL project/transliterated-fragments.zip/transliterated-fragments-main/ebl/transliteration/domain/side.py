from enum import Enum, auto


class Side(Enum):
    LEFT = auto()
    CENTER = auto()
    RIGHT = auto()
