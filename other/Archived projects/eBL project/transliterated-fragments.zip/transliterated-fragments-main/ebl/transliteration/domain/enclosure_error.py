class EnclosureError(Exception):
    pass
