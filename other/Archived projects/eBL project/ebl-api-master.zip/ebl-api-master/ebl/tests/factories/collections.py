import factory


class TupleFactory(factory.BaseListFactory):
    class Meta:
        model = tuple
