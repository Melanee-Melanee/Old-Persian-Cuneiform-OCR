from pymongo_inmemory.downloader import download


if __name__ == "__main__":
    download()
